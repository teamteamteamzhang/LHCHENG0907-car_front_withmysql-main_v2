<template>
  <div id="view" :class="[{'collapsed' : collapsed}]">
    <router-view/>
  </div>
  <sidebar-menu
    class="sidebar"
    :menu="menu"
    :collapsed="collapsed"
    @item-click="onItemClick"
    @update:collapsed="onCollapse"
  />
  <div class="vl">
    <h1>車輛列表</h1>
    <ul>
      <li v-for="item in dataFromMySQL" :key="item.id">
        ID: {{ item.id }}, 種類: {{ item.type }}
      </li>
    </ul>
  </div>
</template>


<script>
import { SidebarMenu } from 'vue-sidebar-menu'
import axios from 'axios';
import 'vue-sidebar-menu/dist/vue-sidebar-menu.css'
import '@fortawesome/fontawesome-free/css/all.css'

export default {
  components: {
    SidebarMenu
  },
  data() {
    return {
      menu: [
        {
          header: '導覽頁',
          hiddenOnCollapse: true,
        },
        {
          href: '/',
          title: '主頁',
          icon: 'fa fa fa-home',
        },
        {
          href: '/charts',
          title: '圖表查詢',
          icon: 'fa fa-chart-area',
          child: [
            {
              href: '/charts/TruckView',
              title: 'Truck',
            },
            {
              href: '/charts/CarView',
              title: 'Car',
            },
            {
              href: '/charts/MotorcycleView',
              title: 'Motorcycle',
            },
            {
              href: '/charts/BicycleView',
              title: 'Bicycle',
            },
            {
              href: '/charts/PedestrianView',
              title: 'Pedestrian',
            }
          ],
        },
      ],
      collapsed: true,
      dataFromMySQL: [] 
    }
  },
  methods: {
    onCollapse(c) {
      this.collapsed = c
    },
    onItemClick() {
      console.log('onItemClick')
    },
    fetchData() {
      axios.get('http://localhost:3000/api/data')
        .then(response => {
          this.dataFromMySQL = response.data;
          
        })
        .catch(error => {
          console.error('There was an error fetching the data:', error);
        });
    }
  },
  mounted() {
    this.fetchData();
  }
}
</script>


<style>
  #view {
    padding-left: 290px;
  }
  #view.collapsed {
    padding-left: 65px;
  }

  .sidebar.v-sidebar-menu .vsm-arrow:after {
    content: "\f105";
    font-family: "FontAwesome";
    background-color: #FBF9F1;
  }
  .sidebar.v-sidebar-menu .collapse-btn:after {
    content: "\f07e";
    font-family: "FontAwesome";
    background-color:#FBF9F1;
  }
  .sidebar {
    background-color: #212121;
  }

  .vl{
  text-align: center;
  list-style-type: none;
  margin: 10px;
  }
</style>
