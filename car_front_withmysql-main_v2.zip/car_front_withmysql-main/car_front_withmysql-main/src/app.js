const express = require('express');
const cors = require('cors');
const db = require('./database'); 
const app = express();

app.use(cors()); 
app.use(express.json());  


app.get('/api/data', (req, res) => {
    db.query('SELECT * FROM carinfo', (error, results) => {
        if (error) {
            return res.status(500).send(error);
        }
        res.status(200).json(results);
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
