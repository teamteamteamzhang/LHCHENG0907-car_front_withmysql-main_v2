import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/charts',
    name: 'charts',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/ChartsView.vue')
  },
  {
    path: '/charts/TruckView',
    name: 'truck',
    component: () => import(/* webpackChunkName: "truck" */ '../views/TruckView.vue')
  },
  {
    path: '/charts/CarView',
    name: 'car',
    component: () => import(/* webpackChunkName: "truck" */ '../views/CarView.vue')
  },
  {
    path: '/charts/MotorcycleView',
    name: 'motorcycle',
    component: () => import(/* webpackChunkName: "truck" */ '../views/MotorcycleView.vue')
  },
  {
    path: '/charts/BicycleView',
    name: 'bicycle',
    component: () => import(/* webpackChunkName: "truck" */ '../views/BicycleView.vue')
  },
  {
    path: '/charts/PedestrainView',
    name: 'pedestrain',
    component: () => import(/* webpackChunkName: "truck" */ '../views/PedestrainView.vue')
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
