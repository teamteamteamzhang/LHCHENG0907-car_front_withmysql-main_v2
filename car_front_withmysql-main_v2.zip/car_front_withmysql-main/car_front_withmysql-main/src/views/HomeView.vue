<template>
  <h1 class="header">Traffic flow and people flow analysis</h1>
  <DoughnutChart :chartData="testData" />
  <BarChart :chartData="barChartData" />
</template>

<script>
import { defineComponent } from 'vue';
import { DoughnutChart, BarChart } from 'vue-chart-3'; // Import BarChart
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

export default defineComponent({
  name: 'HomeView',
  components: { DoughnutChart, BarChart }, // Register BarChart
  data() {
    return {
      testData: {
        labels: ['Truck', 'Car', 'Motorcycle', 'Bicycle', 'Pedestrian'],
        datasets: [
          {
            data: [30, 40, 60, 70, 10],
            backgroundColor: ['#77CEFF', '#0079AF', '#123E6B', '#97B0C4', '#87B0C9'],
          },
        ],
      },
      barChartData: {
        labels: ['Truck', 'Car', 'Motorcycle', 'Bicycle', 'Pedestrian'],
        datasets: [
          {
            label: 'Number of Vehicles',
            data: [30, 40, 60, 70, 10],
            backgroundColor: ['#77CEFF', '#0079AF', '#123E6B', '#97B0C4', '#87B0C9'],
          },
        ],
      }
    };
  },
  mounted() {
    document.body.style.backgroundColor = '#CDE8E5'; 
  }
});
</script>

<style scoped>
.header {
  background-color: #AAD7D9;
  padding: 10px;
  border-radius: 5px;
  text-align: center;
  color: white;  
}
</style>