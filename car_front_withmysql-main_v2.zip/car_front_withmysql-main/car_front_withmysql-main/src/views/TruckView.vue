<template>
      <h1 class="header">Truck Data Analysis</h1>
      <LineChart :chartData="lineChartData" />
      <BarChart :chartData="barChartData" />
      <LineChart :chartData="areaChartData" :options="areaChartOptions" /> <!-- Use LineChart for AreaChart with fill -->
  </template>
  
  <script>
  import { defineComponent } from 'vue';
  import { LineChart, BarChart } from 'vue-chart-3'; // Removed DoughnutChart import
  import { Chart, registerables } from 'chart.js';
  
  Chart.register(...registerables);
  
  export default defineComponent({
    name: 'TruckView',
    components: { LineChart, BarChart }, // Removed DoughnutChart from components
    setup() {
      const lineChartData = {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        datasets: [
          {
            label: 'Truck flow',
            data: [65, 59, 80, 81, 56, 55, 40],
            borderColor: '#77CEFF',
            fill: false,
          },
        ],
      };
  
      const barChartData = {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        datasets: [
          {
            label: 'Truck flow',
            data: [65, 59, 80, 81, 56, 55, 40],
            backgroundColor: '#77CEFF',
          },
        ],
      };
  
      const areaChartData = {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        datasets: [
          {
            label: 'Truck flow',
            data: [65, 59, 80, 81, 56, 55, 40],
            backgroundColor: 'rgba(119, 206, 255, 0.5)',
            borderColor: '#77CEFF',
            fill: true,
          },
        ],
      };
  
      const areaChartOptions = {
        plugins: {
          filler: {
            propagate: true,
          },
        },
      };
  
      return { lineChartData, barChartData, areaChartData, areaChartOptions };
    },
  });
  </script>
  
  <style scoped>
  .header {
    background-color: #AAD7D9;
    padding: 10px;
    border-radius: 5px;
    text-align: center;
    color: white;
  }
  </style>