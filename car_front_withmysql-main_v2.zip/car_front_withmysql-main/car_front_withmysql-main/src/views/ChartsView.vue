<template>
  <div class="charts">
    <h1>This is an search chart page</h1>
  </div>
</template>
